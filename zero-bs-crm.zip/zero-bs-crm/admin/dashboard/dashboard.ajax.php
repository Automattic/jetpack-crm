<?php // phpcs:ignore Squiz.Commenting.FileComment.Missing

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
/**
 * Generate and return dashboard data
 */
function jetpackcrm_dash_refresh() {

	check_ajax_referer( 'zbs_dash_count', 'security' );  // nonce it up...

	// The nonce alone does not gate this: it only proves the request came from a
	// page that printed the nonce. Require the same capability the dashboard page
	// itself registers with ('zbs_dash'), so the CRM aggregates this returns are
	// not served to a logged-in user who has no CRM access.
	if ( ! current_user_can( 'zbs_dash' ) ) {
		wp_send_json_error( array( 'no-action-or-rights' => 1 ), 500, JSON_UNESCAPED_SLASHES );
	}

	// note for WH - looking at the DAL, we can probably extract these into DAL3 helpers?
	global $zbs, $wpdb, $ZBSCRM_t; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

	/**
	 * [06-Nov-2020 09:10:44 UTC] Array
	* (
	*    [action] => jetpackcrm_dash_refresh
	*    [start_date] => 2019-11-06
	*    [end_date] => 2020-11-06
	* )
	*/

	$start_date = sanitize_text_field( $_POST['start_date'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
	$end_date   = sanitize_text_field( $_POST['end_date'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated,WordPress.Security.ValidatedSanitizedInput.MissingUnslash

	$start_date = strtotime( $start_date );
	$end_date   = date_create( $end_date )->setTime( 23, 59, 59 )->getTimestamp();

	$summary = array();
	$chart   = array();

	$range_params = array(
		'count'     => true,
		'newerThan' => $start_date,
		'olderThan' => $end_date,
	);

	$summary[] = array(
		'label'             => __( 'Contacts', 'zero-bs-crm' ),
		'range_total'       => zeroBSCRM_prettifyLongInts( $zbs->DAL->contacts->getContacts( $range_params ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		'alltime_total_str' => sprintf( __( '%s total', 'zero-bs-crm' ), zeroBSCRM_prettifyLongInts( $zbs->DAL->contacts->getFullCount() ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase,WordPress.WP.I18n.MissingTranslatorsComment
		'link'              => jpcrm_esc_link( $zbs->slugs['managecontacts'] ),
	);

	if ( zeroBSCRM_getSetting( 'feat_transactions' ) > 0 ) {
		$summary[] = array(
			'label'             => __( 'Transactions', 'zero-bs-crm' ),
			'range_total'       => zeroBSCRM_prettifyLongInts( $zbs->DAL->transactions->getTransactions( $range_params ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			'alltime_total_str' => sprintf( __( '%s total', 'zero-bs-crm' ), zeroBSCRM_prettifyLongInts( $zbs->DAL->transactions->getFullCount() ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase,WordPress.WP.I18n.MissingTranslatorsComment
			'link'              => jpcrm_esc_link( $zbs->slugs['managetransactions'] ),
		);
	}

	if ( zeroBSCRM_getSetting( 'feat_quotes' ) > 0 ) {
		$summary[] = array(
			'label'             => __( 'Quotes', 'zero-bs-crm' ),
			'range_total'       => zeroBSCRM_prettifyLongInts( $zbs->DAL->quotes->getQuotes( $range_params ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			'alltime_total_str' => sprintf( __( '%s total', 'zero-bs-crm' ), zeroBSCRM_prettifyLongInts( $zbs->DAL->quotes->getFullCount() ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase,WordPress.WP.I18n.MissingTranslatorsComment
			'link'              => jpcrm_esc_link( $zbs->slugs['managequotes'] ),
		);
	}

	if ( zeroBSCRM_getSetting( 'feat_invs' ) > 0 ) {
		$summary[] = array(
			'label'             => __( 'Invoices', 'zero-bs-crm' ),
			'range_total'       => zeroBSCRM_prettifyLongInts( $zbs->DAL->invoices->getInvoices( $range_params ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			'alltime_total_str' => sprintf( __( '%s total', 'zero-bs-crm' ), zeroBSCRM_prettifyLongInts( $zbs->DAL->invoices->getFullCount() ) ), // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase,WordPress.WP.I18n.MissingTranslatorsComment
			'link'              => jpcrm_esc_link( $zbs->slugs['manageinvoices'] ),
		);
	}

	$tz_offset = esc_sql( (string) jpcrm_get_wp_timezone_offset() );
	$wpdb->query( 'SET time_zone = "' . $tz_offset . '";' );

	// next we want the contact chart which is total contacts between the dates grouped by day, week, month, year
	$sql    = $wpdb->prepare( 'SELECT count(ID) as count, YEAR(FROM_UNIXTIME(zbsc_created)) as year FROM ' . $ZBSCRM_t['contacts'] . ' WHERE zbsc_created > %d AND zbsc_created < %d GROUP BY year ORDER BY year', $start_date, $end_date ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
	$yearly = $wpdb->get_results( $sql );

	$sql     = $wpdb->prepare( 'SELECT count(ID) as count, MONTH(FROM_UNIXTIME(zbsc_created)) as month, YEAR(FROM_UNIXTIME(zbsc_created)) as year FROM ' . $ZBSCRM_t['contacts'] . ' WHERE zbsc_created > %d AND zbsc_created < %d GROUP BY month, year ORDER BY year, month', $start_date, $end_date ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
	$monthly = $wpdb->get_results( $sql );

	$sql    = $wpdb->prepare( 'SELECT count(ID) as count, YEARWEEK(FROM_UNIXTIME(zbsc_created), 1) as yearweek FROM ' . $ZBSCRM_t['contacts'] . ' WHERE zbsc_created > %d AND zbsc_created < %d GROUP BY yearweek ORDER BY yearweek', $start_date, $end_date ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
	$weekly = $wpdb->get_results( $sql );

	$sql   = $wpdb->prepare( 'SELECT count(ID) as count, DAY(FROM_UNIXTIME(zbsc_created)) as day, MONTH(FROM_UNIXTIME(zbsc_created)) as month, YEAR(FROM_UNIXTIME(zbsc_created)) as year FROM ' . $ZBSCRM_t['contacts'] . ' WHERE zbsc_created > %d AND zbsc_created < %d GROUP BY day, month, year ORDER BY year, month, day', $start_date, $end_date ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
	$daily = $wpdb->get_results( $sql );

	$zeros = jetpackcrm_create_zeros_array( $start_date, $end_date );

	// get the data ready for the charts
	foreach ( $yearly as $v ) {
		$zeros['year'][ $v->year ] = $v->count;
	}

	foreach ( $monthly as $v ) {
		$datetime_month               = DateTime::createFromFormat( '!m Y', $v->month . ' ' . $v->year );
		$the_month                    = $datetime_month->format( 'M y' );
		$zeros['month'][ $the_month ] = $v->count;
	}

	foreach ( $weekly as $v ) {
		$yearweek                   = str_pad( $v->yearweek, 6, '0', STR_PAD_LEFT );
		$the_week                   = substr( $yearweek, 0, 4 ) . ' W' . substr( $yearweek, 4, 2 );
		$zeros['week'][ $the_week ] = $v->count;
	}

	foreach ( $daily as $v ) {
		$datetime_day             = DateTime::createFromFormat( 'Y-m-d', $v->year . '-' . $v->month . '-' . $v->day );
		$the_day                  = $datetime_day->format( 'd M y' );
		$zeros['day'][ $the_day ] = $v->count;
	}

	$year_labels  = array_keys( $zeros['year'] );
	$month_labels = array_keys( $zeros['month'] );
	$week_labels  = array_keys( $zeros['week'] );
	$day_labels   = array_keys( $zeros['day'] );

	$chart['yearly'] = array(
		'labels' => $year_labels,
		'data'   => array_values( $zeros['year'] ),
	);

	$chart['monthly'] = array(
		'labels' => $month_labels,
		'data'   => array_values( $zeros['month'] ),
	);

	$chart['weekly'] = array(
		'labels' => $week_labels,
		'data'   => array_values( $zeros['week'] ),
	);

	$chart['daily'] = array(
		'labels' => $day_labels,
		'data'   => array_values( $zeros['day'] ),
	);

	// the final output
	$r = array(
		'summary' => $summary,
		'chart'   => $chart,
	);

	wp_send_json( $r, 200, JSON_UNESCAPED_SLASHES );
}
add_action( 'wp_ajax_jetpackcrm_dash_refresh', 'jetpackcrm_dash_refresh' );

/**
 * Store dashboard display settings
 */
function jpcrm_dash_setting() {

	check_ajax_referer( 'zbs_dash_setting', 'security' );  // nonce it up...

	// perms?
	if ( zeroBSCRM_permsCustomers() ) {

		$setting_key             = ( isset( $_POST['the_setting'] ) ? sanitize_text_field( wp_unslash( $_POST['the_setting'] ) ) : '' );
		$acceptable_setting_keys = array( 'settings_dashboard_sales_funnel', 'settings_dashboard_revenue_chart', 'settings_dashboard_recent_activity', 'settings_dashboard_latest_contacts' );

		if ( in_array( $setting_key, $acceptable_setting_keys, true ) ) {

			// default to checked
			$is_checked = ( isset( $_POST['is_checked'] ) ? (int) $_POST['is_checked'] : 1 );

			// retrieve
			$current_user_id = get_current_user_id();

			// update user meta, if legit.
			update_user_meta( $current_user_id, $setting_key, $is_checked );

			// No rights or failed key match
			wp_send_json( array( 'fini' => 1 ), 200, JSON_UNESCAPED_SLASHES );
		}
	}

	// No rights or failed key match
	wp_send_json_error( array( 'no-action-or-rights' => 1 ), 500, JSON_UNESCAPED_SLASHES );
}
add_action( 'wp_ajax_zbs_dash_setting', 'jpcrm_dash_setting' );
