<?php
/*
 * Jetpack CRM
 * https://jetpackcrm.com
 * V2.5
 *
 * Copyright 2020 Automattic
 *
 * Date: 09/01/18
 */

if ( ! defined( 'ZEROBSCRM_PATH' ) ) {
	exit( 0 );
}

function zeroBSCRM_pages_addEditSegment( $potentialID = -1 ) {

	zeroBSCRM_html_addEditSegment( $potentialID );
}

function zeroBSCRM_html_addEditSegment( $potentialID = -1 ) {

	global $zbs;

	#} New or edit
	$newSegment = true;

	// potential
	$segmentID = (int) $potentialID;

	// attempt retrieve (including has rights)
	$segment = $zbs->DAL->segments->getSegment( $segmentID, true );

	$matchtype = ! empty( $segment['matchtype'] ) ? $segment['matchtype'] : '';

	if ( isset( $segment ) && isset( $segment['id'] ) ) {
		// checks out
		$newSegment = false;
	} else {
		// no perms/doesn't checkout
		$segment = false;
	}

	// retrieve conditions/helpers
	$available_conditions             = zeroBSCRM_segments_availableConditions();
	$available_conditions_by_category = zeroBSCRM_segments_availableConditions( true );
	$available_condition_operators    = zeroBSCRM_segments_availableConditionOperators();
	$available_tags_contacts          = $zbs->DAL->getTagsForObjType( array( 'objtypeid' => ZBS_TYPE_CONTACT ) );
	$available_tags_transactions      = $zbs->DAL->getTagsForObjType( array( 'objtypeid' => ZBS_TYPE_TRANSACTION ) );
	$availableStatuses                = zeroBSCRM_getCustomerStatuses( true );

	#} Refresh 2
	?><div class="zbs-semantic wrap" id="zbs-segment-editor">

			<!-- load blocker not used.
			<div class="ui segment hidden" id="zbs-segment-editor-blocker">
				<div class="ui active inverted dimmer">
				<div class="ui text loader"><?php esc_html_e( 'Saving', 'zero-bs-crm' ); ?></div>
				</div>
				<p></p>
			</div> -->


			<!-- edit title -->
			<div class="ui huge centralsimple">

				<div class="field required">
					<label><?php esc_html_e( 'Name this Segment', 'zero-bs-crm' ); ?></label>
					<p style="font-size:0.8em"><?php esc_html_e( 'Enter a descriptive title. This is shown on internal pages and reports.', 'zero-bs-crm' ); ?></p>
					<input placeholder="<?php esc_attr_e( 'e.g. VIP Customers', 'zero-bs-crm' ); ?>" type="text" id="zbs-segment-edit-var-title" name="zbs-segment-edit-var-title" class="max500" value="<?php echo ! empty( $segment['name'] ) ? esc_attr( $segment['name'] ) : ''; ?>">
					<?php echo zeroBSCRM_UI2_messageHTML( 'mini error hidden', '', __( 'This field is required', 'zero-bs-crm' ), '', 'zbs-segment-edit-var-title-err' ); ?>
				</div>

			</div>

			<!-- error segment -->
			<?php if ( is_array( $segment ) && isset( $segment['error'] ) ) { ?>
				<div style="max-width: 600px; margin-left: auto; margin-right: auto; margin-top: 2.5em;">
				<?php

				// generate a user message re: segment error
				$error_code = $zbs->getErrorCode( $segment['error'] );
				if ( $error_code && isset( $error_code['user_message'] ) ) {
					$error_message = $error_code['user_message'];
				} else {
					// error code not present in global error-code array, show code
					$error_message = $segment['error'];
				}
				echo zeroBSCRM_UI2_messageHTML(
					'warning',
					__( 'Segment Warning', 'zero-bs-crm' ),
					__( 'There is an issue with this segment:', 'zero-bs-crm' ) . '<br>' . $error_message,
					'warning',
					'segment-condition-error'
				);
				?>
				</div>
			<?php } ?>

			<!-- edit conditions segment -->
			<div class="ui large centralsimple segment">

				<div class="field" style="padding-top:0;padding-bottom: 0">

							<button class="ui icon small button primary black right floated" type="button" id="zbs-segment-edit-act-add-condition">
						<?php esc_html_e( 'Add Condition', 'zero-bs-crm' ); ?>  <i class="plus icon"></i>
					</button>

					<label><?php esc_html_e( 'Conditions', 'zero-bs-crm' ); ?></label>
					<p><?php esc_html_e( 'Select conditions which will define this segment.', 'zero-bs-crm' ); ?></p>

				</div>

				<div id="zbs-segment-edit-conditions" class="ui segments">
					<!-- built via js -->
				</div>
				<div class="field" style="padding-top:0">
					<?php echo zeroBSCRM_UI2_messageHTML( 'mini hidden', '', __( 'Segments require at least one condition', 'zero-bs-crm' ), '', 'zbs-segment-edit-conditions-err' ); ?>
				</div>

				<div class="field" style="padding-top:1em">
					<label><?php esc_html_e( 'Match Type', 'zero-bs-crm' ); ?></label>
					<p><?php _e( 'Should contacts in this segment match <i>any</i> or <i>all</i> of the above conditions?', 'zero-bs-crm' ); ?></p>
					<select class="ui dropdown" id="zbs-segment-edit-var-matchtype">
						<option value="all"<?php echo $matchtype === 'all' ? ' selected' : ''; ?>><?php esc_html_e( 'Match all Conditions', 'zero-bs-crm' ); ?></option>
						<option value="one"<?php echo $matchtype === 'one' ? ' selected' : ''; ?>><?php esc_html_e( 'Match any one Condition', 'zero-bs-crm' ); ?></option>
					</select>
				</div>
				
				<h4 class="ui horizontal header divider"><?php esc_html_e( 'Continue', 'zero-bs-crm' ); ?></h4>

				<div class="jog-on">
							<button class="ui submit black large icon button" id="zbs-segment-edit-act-p2preview"><?php esc_html_e( 'Preview Segment', 'zero-bs-crm' ); ?> <i class="unhide icon"></i></button>
					<?php

						// where saved, show export button, and mailpoet:
					if ( ! $newSegment ) {

						// export
						if ( zeroBSCRM_permsExport() ) {
							?>
										<a class="ui submit black large icon button" href="<?php echo jpcrm_esc_link( $zbs->slugs['export-tools'] . '&segment-id=' . $segment['id'] ); ?>"><?php esc_html_e( 'Export Segment (.CSV)', 'zero-bs-crm' ); ?> <i class="icon cloud download"></i></a>
							<?php
						}

						// mailpoet support
						do_action( 'jpcrm_segment_edit_export_mailpoet_button' );

					}
					?>
				</div>
			</div>

			<!-- preview segment -->
			<div class="ui large form centralsimple segment hidden" id="zbs-segment-edit-preview">

				<div id="zbs-segment-edit-preview-output">

				</div>
				<?php echo zeroBSCRM_UI2_messageHTML( 'hidden', '', __( 'Your conditions did not produce any matching Contacts. You can still save this segment, but currently there is no one in it!', 'zero-bs-crm' ), '', 'zbs-segment-edit-emptypreview-err' ); ?>

				<div class="jog-on">
					<button class="ui submit positive large icon button" id="zbs-segment-edit-act-p2submit"><?php esc_html_e( 'Save Segment', 'zero-bs-crm' ); ?> <i class="pie chart icon"></i></button>
				</div>
			</div>

			<?php
			// simplify our external sources array
			$external_source_array = array();
			foreach ( $zbs->external_sources as $external_source_key => $external_source_info ) {
				$external_source_array[] = array(
					'key'  => $external_source_key,
					'name' => $external_source_info[0],
				);
			}

			// sort by name
			usort(
				$external_source_array,
				function ( $a, $b ) {
					return strcmp( $a['key'], $b['key'] );
				}
			);

			// phpcs:disable WordPress.WP.I18n.TextDomainMismatch -- this is intentionally using the `mailpoet` text domain
			$jpcrm_mailpoet_status_list = array(
				array(
					'key'  => 'subscribed',
					'name' => __( 'Subscribed', 'mailpoet' ),
				),
				array(
					'key'  => 'unconfirmed',
					'name' => __( 'Unconfirmed', 'mailpoet' ),
				),
				array(
					'key'  => 'unsubscribed',
					'name' => __( 'Unsubscribed', 'mailpoet' ),
				),
				array(
					'key'  => 'inactive',
					'name' => __( 'Inactive', 'mailpoet' ),
				),
				array(
					'key'  => 'bounced',
					'name' => __( 'Bounced', 'mailpoet' ),
				),
			);
			// phpcs:enable WordPress.WP.I18n.TextDomainMismatch
			?>

			<?php
			$jpcrm_segment_lang = array(
				'generalerrortitle'    => __( 'General Error', 'zero-bs-crm' ),
				'generalerror'         => __( 'There was a general error.', 'zero-bs-crm' ),
				'currentlyInSegment'   => __( 'Contacts currently match these conditions.', 'zero-bs-crm' ),
				'previewTitle'         => __( 'Contacts Preview (randomised)', 'zero-bs-crm' ),
				'noName'               => __( 'Unnamed Contact', 'zero-bs-crm' ),
				'noEmail'              => __( 'No Email', 'zero-bs-crm' ),
				'notags'               => __( 'No Tags Found', 'zero-bs-crm' ),
				'nostatuses'           => __( 'No Statuses Found', 'zero-bs-crm' ),
				'noextsources'         => __( 'No External Sources Found', 'zero-bs-crm' ),
				'no_mailpoet_statuses' => __( 'No MailPoet Statuses Found', 'zero-bs-crm' ),
				'nosegmentid'          => __( 'No Segment ID Found.', 'zero-bs-crm' ),
				'to'                   => __( 'to', 'zero-bs-crm' ),
				'eg'                   => __( 'e.g.', 'zero-bs-crm' ),
				'saveSegment'          => __( 'Save Segment', 'zero-bs-crm' ) . ' <i class="save icon">',
				'savedSegment'         => __( 'Segment Saved', 'zero-bs-crm' ) . ' <i class="check circle outline icon">',
				'contactfields'        => '=== ' . __( 'Contact Fields', 'zero-bs-crm' ) . ' ===',
				'default_description'  => __( 'Condition which selects contacts based on given value', 'zero-bs-crm' ),
			);
			?>
			<script type="text/javascript">
				var zbsSegment = <?php echo wp_json_encode( $segment, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_available_conditions = <?php echo wp_json_encode( $available_conditions, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_available_conditions_by_category = <?php echo wp_json_encode( $available_conditions_by_category, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsAvailableConditionOperators = <?php echo wp_json_encode( $available_condition_operators, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_available_contact_tags = <?php echo wp_json_encode( $available_tags_contacts, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_available_transaction_tags = <?php echo wp_json_encode( $available_tags_transactions, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsAvailableStatuses = <?php echo wp_json_encode( $availableStatuses, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsSegmentStemURL = <?php echo wp_json_encode( jpcrm_esc_link( 'edit', -1, 'segment', true ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_contact_stem_URL = <?php echo wp_json_encode( jpcrm_esc_link( 'view', -1, 'contact', true ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsSegmentListURL = <?php echo wp_json_encode( jpcrm_esc_link( $zbs->slugs['segments'] ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsSegmentSEC = <?php echo wp_json_encode( wp_create_nonce( 'zbs-ajax-nonce' ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var zbsSegmentLang = <?php echo wp_json_encode( $jpcrm_segment_lang, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
				var jpcrm_external_source_list = <?php echo wp_json_encode( $external_source_array, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;

				<?php
				// any extra js? e.g. MailPoet Export functionality
				do_action( 'segment_edit_extra_js' );
				?>

				var jpcrm_mailpoet_status_list = <?php echo wp_json_encode( $jpcrm_mailpoet_status_list, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?>
			</script>
			</div>
	<?php
}

function zeroBSCRM_segments_typeConversions( $value = '', $type = '', $operator = '', $direction = 'in' ) {

	if ( ! empty( $value ) ) {
		$available_conditions = zeroBSCRM_segments_availableConditions();

		if ( isset( $available_conditions[ $type ]['conversion'] ) ) {

			// INBOUND (e.g. post -> db)
			// For dates, convert to UTS here. (EXCEPT FOR daterange/datetimerange!, dealing with that in zeroBSCRM_segments_filterConditions for now)
			if ( $direction == 'in' && $operator != 'daterange' && $operator != 'datetimerange' && $operator != 'nextdays' && $operator != 'previousdays' ) {
				switch ( $available_conditions[ $type ]['conversion'] ) {
					case 'date-to-uts':
								$local_date_time = new DateTime( $value, wp_timezone() );
								$local_date_time->setTimezone( new DateTimeZone( 'UTC' ) );
								$value = $local_date_time->format( 'Y-m-d H:i' );
						// convert date to uts
						$value = zeroBSCRM_locale_dateToUTS( $value, true );

						// for cases where we're saying 'after' {timestamp} we add 1 second
						if ( $operator == 'after' ) {
							$value += 1;
						}

						break;
				}
			} elseif ( $direction == 'out' && $operator != 'nextdays' && $operator != 'previousdays' ) {
				// OUTBOUND (e.g. exposing dates in segment editor)

				// OUTBOUND (e.g. exposing dates in segment editor)
				switch ( $available_conditions[ $type ]['conversion'] ) {

					case 'date-to-uts':
						// for cases where we're saying 'after' {timestamp} we add 1 second
						// here we retract that addition
						if ( $operator == 'after' ) {
							$value -= 1;
						}

						// convert uts back to date
								$value = zeroBSCRM_date_i18n_plusTime( 'Y-m-d', $value );

						break;
				}
			}
		}
	}

	return $value;
}
