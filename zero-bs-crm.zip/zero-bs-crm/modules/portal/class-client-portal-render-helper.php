<?php
/*
* Jetpack CRM
* https://jetpackcrm.com
*
* Client Portal Render Helper
*
*/
namespace Automattic\JetpackCRM;

defined( 'ZEROBSCRM_PATH' ) || exit( 0 );

/**
 *
 * Client Portal class that helps rendering the Client Portal HTML.
 */
class Client_Portal_Render_Helper {
	public $parent_portal;

	public function __construct( $parent ) {
		$this->parent_portal = $parent;
	}

	/**
	 * Shows an object load error and dies.
	 */
	function show_single_obj_error_and_die() {
		echo '<center>';
		echo '<h3>' . esc_html__( 'Error loading object', 'zero-bs-crm' ) . '</h3>';
		echo esc_html__( 'Either this object does not exist or you do not have permission to view it.', 'zero-bs-crm' );
		echo '</center>';
		die( 0 );
	}

	#} MS - can you make this work with templates, couldn't so dumped (dumbly) here for now:
	function portal_footer() {
		// won't return ours :/
		##WLREMOVE
		global $zbs;
		$showpoweredby_public = $zbs->settings->get( 'showpoweredby_public' ) === 1 ? true : false;
		if ( $showpoweredby_public ) {
			?>
			<div class="zerobs-portal-poweredby" style="font-size:11px;position:absolute;bottom:25px;right:50px;font-size:12px;">
				<?php echo wp_kses( sprintf( __( 'Client Portal by <a href="%s" target="_blank">Jetpack CRM</a>', 'zero-bs-crm' ), esc_url( $zbs->urls['home'] ) ), $zbs->acceptable_restricted_html ); ?>
			</div>
			<?php
		}
		##/WLREMOVE
	}

	/*
	* Outputs html which shows 'you are viewing this as an admin' dialog on portal pages
	*/
	function portal_viewing_as_admin_banner( $admin_message = '' ) {

		global $zbs;

		?>
		<div class="jpcrm-client-portal-admin-banner">

			<div class="alert alert-info">
				<strong><?php esc_html_e( 'You are viewing the Client Portal as an admin.', 'zero-bs-crm' ); ?></strong>

				<?php if ( ! empty( $admin_message ) ) { ?>
					<p class="admin-message"><?php echo esc_html( $admin_message ); ?></p>
				<?php } ?>
				<?php ##WLREMOVE ?>
				<p>
					<a href="<?php echo esc_url( $zbs->urls['kbclientportal'] ); ?>" target="_blank"><?php esc_html_e( 'Learn more about the Client Portal', 'zero-bs-crm' ); ?></a>
				</p>
				<?php ##/WLREMOVE ?>

			</div>

			<?php $this->admin_message(); ?>


		</div>
		<?php
	}

	// upsell shown to admins across whole portal as they view as admin
	function admin_message() {

		// temp fix
		if ( jpcrm_perms_manage_options() && ! function_exists( 'zeroBSCRM_cpp_register_endpoints' ) ) {

			##WLREMOVE
			?>

		<script type="text/javascript">
			jQuery(function(){
				jQuery('#zbs-close-cpp-note').on( 'click', function(){
					jQuery('.zbs-client-portal-pro-note').remove();
				});
			});
		</script>
			<?php
			##/WLREMOVE

		}

		return '';
	}

	function portal_nav( $selected_item = 'dashboard', $do_echo = true ) {
		global $wp_query;

		$nav_html        = '';
		$zbsWarn         = '';
		$dash_link       = zeroBS_portal_link( 'dash' );
		$portal_root_url = \jpcrm_get_client_portal_root_url();
		$nav_html       .= '	<ul id="zbs-nav-tabs">';

		foreach ( $this->parent_portal->endpoints as $endpoint ) {
			if ( $endpoint->hide_from_menu ) {
				continue;
			}
			$link  = $endpoint->slug === 'dashboard' ? $portal_root_url : $portal_root_url . $endpoint->slug;
			$class = $endpoint->slug === $selected_item ? 'active' : '';
			// produce the menu from the array of menu items (easier to extend :-) ).
			// WH: this assumes icon, otehrwise it'll break! :o
			$nav_html .= "<li class='" . esc_attr( $class ) . "'><a href='" . esc_url( $link ) . "'><i class='fa " . esc_attr( $endpoint->icon ) . "'></i>" . esc_html( $endpoint->name ) . '</a></li>';
		}

		$zbs_logout_text = __( 'Log out', 'zero-bs-crm' );
		$zbs_logout_text = apply_filters( 'zbs_portal_logout_text', $zbs_logout_text );

		$zbs_logout_icon = 'fa-sign-out';
		$zbs_logout_icon = apply_filters( 'zbs_portal_logout_icon', $zbs_logout_icon );

		$nav_html .= "<li><a href='" . esc_url( wp_logout_url( $dash_link ) ) . "'><i class='fa " . esc_attr( $zbs_logout_icon ) . "' aria-hidden='true'></i>" . esc_html( $zbs_logout_text ) . '</a></li>';
		$nav_html .= '</ul>';

		// echo or return nav HTML depending on flag; defaults to echo (legacy support)
		if ( $do_echo ) {
			echo $nav_html;
		} else {
			return $nav_html;
		}
	}
}
